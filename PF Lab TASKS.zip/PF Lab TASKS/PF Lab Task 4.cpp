#include <iostream>
using namespace std;
int main () 
{
	int y;
	cout << "Enter the number" << endl;
	cin >> y;
	if (y%2==0) {
		cout << "The Number is even " << endl;
	}
	else {
		cout << "The Number is odd" << endl;
	}
	return 0;

}